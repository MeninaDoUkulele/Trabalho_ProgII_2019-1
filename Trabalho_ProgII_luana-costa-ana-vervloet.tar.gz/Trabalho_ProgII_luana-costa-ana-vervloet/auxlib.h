float mediaParcial(float p1, float p2, float p3, float p4);
float mediaFinal(float p1, float p2, float p3, float p4, float pf);
void medias(float p1, float p2, float p3, float p4, float pf, float *mP, float *mF, int count);
void printaAlfabetica(char nome[30][10], int contador, FILE *saida);
void printaSuplente(char suplente[30][100], int s);
